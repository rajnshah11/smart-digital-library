import boto3
import pymongo
from pdfplumber import PDF
from easyocr import Reader
from datetime import datetime

# Initialize AWS S3 client
s3 = boto3.client('s3')

# MongoDB connection string (replace with your own)
mongo_client = pymongo.MongoClient("mongodb+srv://rajnshah:rajshah@cluster0.jsbcp.mongodb.net/?retryWrites=true&w=majority")
db = mongo_client["learning_library"]
collection = db["notes"]

def lambda_handler(event, context):
    # Get S3 bucket and object details from the event
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    file_key = event['Records'][0]['s3']['object']['key']
    
    # Download file from S3 to /tmp directory (Lambda's writable space)
    local_file_path = f"/tmp/{file_key.split('/')[-1]}"
    s3.download_file(bucket_name, file_key, local_file_path)
    
    # Determine if the file is an image or PDF and process accordingly
    if file_key.endswith('.pdf'):
        process_pdf(local_file_path, file_key)
    else:
        process_image(local_file_path, file_key)

def process_pdf(file_path, file_key):
    """Extract text from each page of a PDF file."""
    with PDF(open(file_path, 'rb')) as pdf:
        for page_number, page in enumerate(pdf.pages):
            text = page.extract_text()  # Extract text from page
            store_in_mongodb(file_key, page_number + 1, text)

def process_image(file_path, file_key):
    """Extract text from an image using EasyOCR."""
    reader = Reader(['en'])  # Initialize EasyOCR reader for English language
    results = reader.readtext(file_path)  # Perform OCR on the image
    
    # Combine all detected text into a single string
    text = " ".join([res[1] for res in results])
    store_in_mongodb(file_key, 1, text)

def store_in_mongodb(file_key, page_number, text):
    """Store extracted text in MongoDB."""
    document = {
        "file_name": file_key,
        "page_number": page_number,
        "extracted_text": text,
        "timestamp": datetime.utcnow()
    }
    collection.insert_one(document)  # Insert document into MongoDB collection
    
    
import boto3
import pymongo
import json
import logging

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# MongoDB connection string (replace with your own)
mongo_client = pymongo.MongoClient("mongodb+srv://rajnshah:rajshah@cluster0.jsbcp.mongodb.net/?retryWrites=true&w=majority")
db = mongo_client["learning_library"]
collection = db["notes"]

def lambda_handler(event, context):
    logger.info("Lambda function triggered with event: %s", json.dumps(event))
    
    textract_client = boto3.client('textract')

    try:
        # Extract bucket name and file key from the event
        for record in event['Records']:
            bucket_name = record['s3']['bucket']['name']
            file_key = record['s3']['object']['key']
            logger.info("Processing file from bucket: %s, key: %s", bucket_name, file_key)

            # Call Textract to analyze the document
            response = textract_client.analyze_document(
                Document={'S3Object': {'Bucket': bucket_name, 'Name': file_key}},
                FeatureTypes=["TABLES", "FORMS"]
            )
            logger.info("Textract response received: %s", json.dumps(response))

            # Extract text from Textract response
            extracted_text_blocks = response['Blocks']
            extracted_texts = [block['Text'] for block in extracted_text_blocks if block['BlockType'] == 'LINE']
            extracted_text_str = "\n".join(extracted_texts)
            logger.info("Extracted text: %s", extracted_text_str)

            # Save extracted text to MongoDB
            document_data = {
                "file_url": f"https://{bucket_name}.s3.amazonaws.com/{file_key}",
                "extracted_text": extracted_text_str,
            }
            collection.insert_one(document_data)
            logger.info("Document saved to MongoDB: %s", document_data)

    except Exception as e:
        logger.error("Error processing file: %s", str(e))
        raise

    return {
        'statusCode': 200,
        'body': json.dumps('Text extraction complete!')
    }